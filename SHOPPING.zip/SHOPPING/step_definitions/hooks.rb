
Before do |scenario|
  set_root_page(ExampleRootPage)
  @browser_engine.create_new_browser
end
class RegisterPage < ExampleRootPage
  add_id_element(:div, /Register/, class: 'page-title')
  # add_route(:RegisterPage, :register)

  def create_elements
    # add_static_text(:computer, element_type: :a, xpath: "//ul[@class='top-menu']//a[contains(text(),'Computers')]")
    # add_static_text(:electronics, element_type: :h1, xpath: "//ul[@class='top-menu']//a[contains(text(),'Electronics')]")
    # add_button(:register, element_type: :link, class: 'ico-register')
    add_text_field(:password , id: 'Password')
    add_text_field(:confirm_password , id: 'ConfirmPassword' )
    add_text_field(:companyName, element_type: :input, id: 'Company')
    add_button(:register_confirmation, element_type: :input, id: 'register-button')
    add_select_list()
  end
end
